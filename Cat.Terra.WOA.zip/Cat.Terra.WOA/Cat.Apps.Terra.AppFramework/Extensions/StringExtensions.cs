﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cat.Apps.Terra.AppFramework
{
    public static class StringExtensions
    {
        public static byte[] ToByteArray(this string value)
        {
            byte[] bytes = new byte[value.Length * sizeof(char)];
            System.Buffer.BlockCopy(value.ToCharArray(), 0, bytes, 0, bytes.Length);
            return bytes;
        }

        public static string MakeNullIfEmpty(this string value)
        {
            if (value == string.Empty)
            {
                value = null;
            }
            return value;
        }

        public static string MakeEmptyIfNull(this string value)
        {
            if (value == null)
            {
                value = string.Empty;
            }
            return value;
        }

        public static bool IsNullOrEmpty(this string value)
        {
            return string.IsNullOrEmpty(value);
        }

        public static string TryCopy(this string value)
        {
            if (value == null)
                return null;
            else
                return string.Copy(value);
        }

        public static string TryTrim(this string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                return value;
            }
            else
            {
                return value.Trim();
            }
        }

        public static string TryTruncate(this string value, int maxLength, out bool truncated)
        {
            if (value == null)
            {
                truncated = false;
                return value;
            }
            if (value.Length > maxLength)
            {
                value = value.Substring(0, maxLength);
                truncated = true;
            }
            else
                truncated = false;
            return value;
        }

        public static string StripNonNumeric(this string value)
        {
            return new string(value.Where(c => char.IsDigit(c)).ToArray());
        }

        public static T ToEnum<T>(this string value)
        {
            string valueCopy;
            if ((value == null) || (Enum.GetNames(typeof(T)).Contains(value) == false))
            {
                valueCopy = Enum.GetName(typeof(T), 0);
            }
            else
            {
                valueCopy = value.ToString();
            }
            return (T)Enum.Parse(typeof(T), valueCopy);
        }
      
    }
}
