﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace Cat.Apps.Terra.AppFramework
{
   public interface IRepositoryBase<I, T>
    {
        void Delete(I identity);
        T Get(I identity);
        R Get<R>(I identity) where R : T, new();
        R[] Find<R>(Expression<Func<R, bool>> predicate) where R : T, new();
        R[] Find<R>(Expression<Func<R, bool>>[] predicates) where R : T, new();
        T[] Find(Expression<Func<T, bool>> predicate);
        T[] Find(Expression<Func<T, bool>>[] predicates);
        IQueryable<T> GetAll();
        IQueryable<R> GetAll<R>() where R : T, new();
    }
}
