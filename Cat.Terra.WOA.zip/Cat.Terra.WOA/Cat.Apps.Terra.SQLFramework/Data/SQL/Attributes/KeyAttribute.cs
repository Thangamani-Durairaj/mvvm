﻿using System;

namespace Cat.Apps.Terra.SQLFramework.Data.SQL.Attributes
{
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class KeyAttribute : Attribute
    {
    }
}
