﻿using Dapper.Extensions.Linq.Core.Configuration;

namespace Cat.Apps.Terra.SQLFramework
{

    internal class CustomContainer : IContainer
    {
        public void Build(DapperConfiguration configuration) { }
    } 
 

}
