﻿using Dapper.Extensions.Linq;
using Dapper.Extensions.Linq.Builder;
using Dapper.Extensions.Linq.Core;
using Dapper.Extensions.Linq.Core.Builder;
using Dapper.Extensions.Linq.Core.Implementor;
using Dapper.Extensions.Linq.Core.Predicates;
using Dapper.Extensions.Linq.Core.Sessions;
using Dapper.Extensions.Linq.Predicates;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

namespace Cat.Apps.Terra.SQLFramework.Data.SQL
{
    internal class CustomEntityBuilder<T> : IEntityBuilder<T> where T : class, IEntity
    {
        private readonly IDapperSession _session;
        private readonly IDapperImplementor _implementor;
        private readonly Expression<Func<T, bool>> _expression;
        private readonly IList<ISort> _sort;
        private int? _take;
        private int? _timeout;
        private bool _nolock;

        public CustomEntityBuilder(IDapperSession session, IDapperImplementor implementor, Expression<Func<T, bool>> expression)
        {
            _session = session;
            _implementor = implementor;
            _expression = expression;
            _sort = new List<ISort>();
        }

        private IEnumerable<T> ResolveEnities()
        {
            IPredicateGroup predicate = QueryBuilder<T>.FromExpression(_expression);

            IPredicateGroup p = predicate?.Predicates == null ? null : predicate;
            return _implementor.GetList<T>(_session.Connection, p, _sort, _session.Transaction, _timeout, false, _take, _nolock);
        }

        public IEnumerable<T> AsEnumerable()
        {
            return ResolveEnities();
        }

        public bool Any()
        {
            return ResolveEnities().Any();
        }

        public IList<T> ToList()
        {
            return ResolveEnities().ToList();
        }

        public int Count()
        {
            return ResolveEnities().Count();
        }

        public T Single()
        {
            return ResolveEnities().Single();
        }

        public T SingleOrDefault()
        {
            return ResolveEnities().SingleOrDefault();
        }

        public T FirstOrDefault()
        {
            return ResolveEnities().FirstOrDefault();
        }

        public IEntityBuilder<T> OrderBy(Expression<Func<T, object>> expression)
        {
            PropertyInfo propertyInfo = ReflectionHelper.GetProperty(expression) as PropertyInfo;
            if (propertyInfo == null) return this;

            var sort = new Sort
            {
                PropertyName = propertyInfo.Name,
                Ascending = true
            };
            _sort.Add(sort);

            return this;
        }

        public IEntityBuilder<T> OrderByDescending(Expression<Func<T, object>> expression)
        {
            PropertyInfo propertyInfo = ReflectionHelper.GetProperty(expression) as PropertyInfo;
            if (propertyInfo == null) return this;

            var sort = new Sort
            {
                PropertyName = propertyInfo.Name,
                Ascending = false
            };
            _sort.Add(sort);

            return this;
        }

        public IEntityBuilder<T> Take(int number)
        {
            _take = number;
            return this;
        }

        /// <summary>
        /// Timeouts cannot be specified for SqlCe, these will remain zero.
        /// </summary>
        /// <param name="timeout"></param>
        /// <returns></returns>
        public IEntityBuilder<T> Timeout(int timeout)
        {
            _timeout = timeout;
            return this;
        }

        public IEntityBuilder<T> Nolock()
        {
            _nolock = true;
            return this;
        }
    }
}
