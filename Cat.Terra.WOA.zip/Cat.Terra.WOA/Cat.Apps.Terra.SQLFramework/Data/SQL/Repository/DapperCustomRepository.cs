﻿using Dapper.Extensions.Linq.Builder;
using Dapper.Extensions.Linq.Core;
using Dapper.Extensions.Linq.Core.Builder;
using Dapper.Extensions.Linq.Core.Implementor;
using Dapper.Extensions.Linq.Core.Sql;
using Dapper.Extensions.Linq.Implementor;
using Dapper.Extensions.Linq.Repositories;
using Dapper.Extensions.Linq.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;

namespace Cat.Apps.Terra.SQLFramework.Data.SQL
{
    internal class DapperCustomRepository<T> : DapperRepository<T> where T : class, IEntity
    {
        private IDapperImplementor Instance;
        private ISqlGenerator SqlGenerator;

        internal DapperCustomRepository(DapperCustomSessionContext sessionContext) : base(sessionContext)
        {
            SqlGenerator = new SqlGeneratorImpl(sessionContext.Configuration);
            Instance = new DapperImplementor(SqlGenerator);
        }

        internal IDbConnection GetConnection()
        {
            return base.GetCurrentSession().Connection;
        }

        internal IDbTransaction GetTransaction()
        {
            return base.GetCurrentSession().Transaction;
        }

        internal ISqlGenerator GetSqlGenerator()
        {
            return SqlGenerator;
        }

        internal T Get(string id)
        {
            return Instance.Get<T>(GetConnection(), id, GetTransaction(), null);
        }

        public override T Get(int id)
        {
            return Instance.Get<T>(GetConnection(), id, GetTransaction(), null);
        }

        public override T Get(Guid id)
        {
            return Instance.Get<T>(GetConnection(), id, GetTransaction(), null);
        }

        public override dynamic Insert(T item)
        {
            return Instance.Insert(GetConnection(), item, GetTransaction(), null);
        }

        public override void Insert(IEnumerable<T> items)
        {
            Instance.Insert(GetConnection(), items, GetTransaction(), null);
        }

        public override bool Update(T item)
        {
            return Instance.Update(GetConnection(), item, GetTransaction(), null);
        }

        public override bool Delete(T item)
        {
            return Instance.Delete(GetConnection(), item, GetTransaction(), null);
        }

        public override IList<T> GetList()
        {
            return Instance.GetList<T>(GetConnection(), null, null, GetTransaction(), null, false, null, false).ToList();
        }

        public override IEntityBuilder<T> Query(Expression<Func<T, bool>> predicate)
        {
            return new CustomEntityBuilder<T>(GetCurrentSession(), Instance, predicate);
        }

        public override int Count(Expression<Func<T, bool>> predicate = null)
        {
            return Instance.Count<T>(GetConnection(), QueryBuilder<T>.FromExpression(predicate), GetTransaction(), null);
        }

        public override bool Delete(Expression<Func<T, bool>> predicate = null)
        {
            return Instance.Delete<T>(GetConnection(), QueryBuilder<T>.FromExpression(predicate), GetTransaction(), null);
        }
    }
}
