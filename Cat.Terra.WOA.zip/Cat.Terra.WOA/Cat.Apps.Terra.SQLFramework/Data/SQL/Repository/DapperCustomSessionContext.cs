﻿using Dapper.Extensions.Linq.Core;
using Dapper.Extensions.Linq.Core.Attributes;
using Dapper.Extensions.Linq.Core.Configuration;
using Dapper.Extensions.Linq.Core.Sessions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace Cat.Apps.Terra.SQLFramework.Data.SQL
{
    internal class DapperCustomSessionContext : IDapperSessionContext
    {
        private IDictionary<string, IDapperSession> _sessionDictionary;
        private readonly DapperConfiguration _configuration;
        private readonly IDapperSessionFactory _factory;

        public DapperCustomSessionContext(IDapperSessionFactory factory, DapperConfiguration configuration)
        {
            _factory = factory;
            _configuration = configuration;
            Bind();
        }

        public IDapperSession GetSession<TEntity>() where TEntity : class, IEntity
        {
            return GetSession(typeof(TEntity));
        }

        public IDapperSession GetSession(Type entityType)
        {
            if (_sessionDictionary == null)
                throw new InvalidOperationException("No sessions bound");

            var attribute = entityType.GetCustomAttribute<DataContextAttribute>();
            var sessionName = attribute == null ? _configuration.DefaultConnectionStringName : attribute.ConnectionStringName;

            IDapperSession session;
            if (_sessionDictionary.TryGetValue(sessionName, out session))
                return session;

            throw new Exception(string.Format("Session for entity {0} not found.", entityType.Name));
        }

        public void Dispose()
        {
            if (_sessionDictionary != null)
                Unbind();
        }

        public void Bind()
        {
            if (_sessionDictionary != null)
                return;

            _sessionDictionary = _factory.OpenAndBind();
        }

        public void Unbind()
        {
            if (_sessionDictionary == null)
                return;

            List<string> keys = _sessionDictionary.Keys.ToList();

            foreach (var conString in keys)
            {
                IDapperSession session = _sessionDictionary[conString];
                if (session.Transaction != null)
                {
                    session.Transaction.Rollback();
                    session.Transaction.Dispose();
                    session.Transaction = null;
                }
                session.Close();
                session.Dispose();
            }

            _sessionDictionary = null;
        }

        public IEnumerable<IDapperSession> BoundedSessions => _sessionDictionary?.Values.ToList() ?? new List<IDapperSession>();
        public DapperConfiguration Configuration => _configuration;
    }
}
