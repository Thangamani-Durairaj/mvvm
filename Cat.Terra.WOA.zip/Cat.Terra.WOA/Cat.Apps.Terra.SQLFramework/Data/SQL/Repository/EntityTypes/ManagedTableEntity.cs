﻿using Dapper.Extensions.Linq.Core;
using Dapper.Extensions.Linq.Core.Attributes;
using System;

namespace Cat.Apps.Terra.SQLFramework.Data.SQL
{
    public abstract class ManagedTableEntity : IEntity
    {
        [MapTo("CreatedBy")]
        public string CreatedBy { get; set; }
        [MapTo("CreatedDateTime")]
        public DateTime CreatedDateTime { get; set; }
        [MapTo("ModifiedBy")]
        public string ModifiedBy { get; set; }
        [MapTo("ModifiedDateTime")]
        public DateTime ModifiedDateTime { get; set; }
    }
}
