﻿using Dapper.Extensions.Linq.Core;

namespace Cat.Apps.Terra.SQLFramework.Data.SQL
{
    public abstract class UnManagedTableEntity : IEntity
    {
    }
}
