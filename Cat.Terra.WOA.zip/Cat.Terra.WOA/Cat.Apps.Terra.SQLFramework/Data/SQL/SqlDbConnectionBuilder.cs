﻿using Dapper.Extensions.Linq.Sql;
using System.Configuration;
using Cat.Apps.Terra.SQLFramework.Data.SQL;
//using Cat.Apps.Terra.Util.Common;
namespace Cat.Apps.Terra.SQLFramework
{
    public class SqlDbConnectionBuilder : IDbConnectionBuilder
    {
        //private readonly ISettingLoader settingLoader = new KeyVaultSettingLoader();
        public override string GetDBConnectionString()
        {
            return string.Empty;
           // return Helper.ConstructDbConnectionString(ConfigurationManager.ConnectionStrings["SqlConnectionString"].ConnectionString);
           // return settingLoader.ResolveSetting("DBConnectionString");;
        }

        public override global::Dapper.Extensions.Linq.Core.Sql.ISqlDialect GetDBDialect()
        {
            return new SqlServerDialect();
        }
    }
}
