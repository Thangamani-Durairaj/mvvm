﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cat.Terra.WOA.DA
{
    public enum JobStatus
    {
        todo,
        doingnotloaded
    }
    public enum EnumJobUpdateoptions
    {
        UpdatedinApex,
        ApexDone,
        StartDoing,
        Loaded,
        StopDoing
    }
}
