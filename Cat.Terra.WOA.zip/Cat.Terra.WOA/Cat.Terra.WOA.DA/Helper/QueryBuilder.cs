﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cat.Terra.WOA.DA
{
    public static class QueryBuilder
    {
        public static string FieldstoUpdate_forApexupdate ="";
        public static string FieldstoUpdate_forApexDone = "Update job set JobState=@JobState,DoneReason=@DoneReason,ModifiedDateTime=@ModifiedDateTime,ModifiedBy=@ModifiedBy,JobHash=@JobHash where JobId=@JobId";
        public static string FieldstoUpdate_forCommand_StartDoing = "Update job set JobState=@JobState,IsLoaded=@IsLoaded,StartDoingDateTime=@StartDoingDateTime,LoaderID=@LoaderID,LoaderCode=@LoaderCode,JobHash=@JobHash where JobId=@JobId ";
        public static string FieldstoUpdate_forCommand_Loaded = "Update job set JobState=CASE WHEN @JobState > JobState THEN @JobState ELSE JobState END ,IsLoaded=@IsLoaded,StopDoingDateTime=@StopDoingDateTime,LoaderID=@LoaderID,LoaderCode=@LoaderCode,LoaderPassCount=@LoaderPassCount,LoaderMaterialWeight=@LoaderMaterialWeight,JobHash=@JobHash where JobId=@JobId ";
        public static string FieldstoUpdate_forCommand_StopDoing = "Update job set JobState=@JobState,IsLoaded=@IsLoaded,StartDoingDateTime=@StartDoingDateTime,LoaderID=@LoaderID,LoaderCode=@LoaderCode,JobHash=@JobHash where JobId=@JobId ";
    }
}