﻿using System;
using Cat.Apps.Terra.AppFramework;
using Cat.Terra.WOA.Entities;

namespace Cat.Terra.WOA.DA
{
    public interface IJobsRepository : IManagedIdentityRepository<int, Job>
    {
        Job[] ListJobs(Int32[] SiteID);
        void Update(string Query, object entity);
    }
}
