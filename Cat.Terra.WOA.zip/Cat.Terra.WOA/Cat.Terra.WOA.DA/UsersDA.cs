﻿using System;

namespace Cat.Terra.WOA.DA
{
    public class UsersDA
    {
    }
}
