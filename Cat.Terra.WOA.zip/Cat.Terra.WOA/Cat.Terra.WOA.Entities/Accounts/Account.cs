﻿using System;

namespace Cat.Terra.WOA.Entities
{
    public class Account
    {
    }
}
