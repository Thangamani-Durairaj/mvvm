﻿using System.Diagnostics.CodeAnalysis;

namespace Cat.Terra.WOA.Entities.ViewModels
{
    /// <summary>
    /// Site
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class Site
    {
        /// <summary>
        /// Site Id
        /// </summary>
        public int SiteId { get; set; }
        /// <summary>
        /// Site Name
        /// </summary>
        public string SiteName { get; set; }
        /// <summary>
        /// Location
        /// </summary>
        public string Location { get; set; }
        /// <summary>
        /// ActiveLoaders
        /// </summary>
        public int ActiveLoaders { get; set; }
        /// <summary>
        /// MaterialDispatched
        /// </summary>
        public int MaterialDispatched { get; set; }
        /// <summary>
        /// TrucksDispatched
        /// </summary>
        public int TrucksDispatched { get; set; }
        /// <summary>
        /// ActiveJobs
        /// </summary>
        public int ActiveJobs { get; set; }

    }
}
