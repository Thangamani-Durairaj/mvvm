﻿namespace Cat.Terra.Jobs.WebAPI.Business
{
    /// <summary>
    /// Constants
    /// </summary>
    public static class Constants
    {
        public const string DoneJobState = "done";
        public const string Ucid = "Ucid";
        public const string OAuth = "OAuth";
    }
}
