﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Cat.Terra.WOA.Entities;

namespace Cat.Terra.WOA.Services
{
    public interface IJobService
    {
        Task<IEnumerable<Job>> GetJobsAsync(JobRequest request);
    }
}
