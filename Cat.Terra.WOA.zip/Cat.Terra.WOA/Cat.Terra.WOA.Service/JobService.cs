﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Cat.Terra.WOA.Business;
using Cat.Terra.WOA.Entities;

namespace Cat.Terra.WOA.Services
{
    public class JobService : IJobService
    {
        private IJobBusiness _JobBusiness;

        public JobService(IJobBusiness JobBusiness)
        {
            _JobBusiness = JobBusiness;
        }
       
        public async Task<IEnumerable<Job>> GetJobsAsync(JobRequest request)
        {
            return await _JobBusiness.GetJobsAsync(request);
        }
    }
}
