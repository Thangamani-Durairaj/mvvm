declare @i int=2000001
while (@i<=4000000)
begin
insert into [dbo].[jobs]([siteid],[sitename]
           ,[jobstate],[zoneid]
           ,[zonecode],[zonename]
           ,[truckid],[truckcode]
           ,[truckname],[materialid]
           ,[materialcode]
           ,[materialname]
           ,[loadercode]
           ,[loadername]
           ,[loaderpasscount]
           ,[targetmaterialwt]
           ,[loadermaterialwt]
           ,[timeonsite]
           ,[timebeforeloaded]
           ,[timeafterloaded]
           ,[ucid]
           ,[jobid]
           ,[origin]
           ,[isloaded]
           ,[totalrecords]
           ,[ready]
           ,[startdoing]
           ,[stopdoing]
           ,[done],createdby,modifiedby) values(
		   @i,'sitename'+str(@i),'todo',@i,
		   'zonecode'+str(@i),
		   'zonename'+str(@i),@i,
		   'truckcode'+str(@i),
		   'truckname'+str(@i),@i,
		   'materialcode'+str(@i),'materialname'+str(@i),'loadercode'+str(@i),'loadername'+str(@i),100.50,80.00,20.00,
		   '01:30','00:20','00:30','ucid'+str(@i),@i,'origin'+str(@i),1,10,getdate()+1,getdate()+1,getdate()+1,getdate()+1,1,1)
		   set @i=@i+1
end


-- select * from jobs - 100000 - 01:35
-- select * from jobs - 500000 - 01:35
-- select * from jobs where siteid >=1000 and siteid <=2000 - 00:00:02

-- select * from jobs where siteid >=100000 and siteid <=100100  - 00:00:02

[siteid],[sitename],[zoneid]
           ,[zonecode],[zonename]
           ,[truckid],[truckcode]
           ,[truckname],[materialid]
           ,[materialcode]
           ,[materialname]
           ,[loadercode]
           ,[loadername]

declare @text varchar(100) = '1500000'
 select * from jobs where siteid like '%'+@text+'%' or sitename like '%'+@text+'%' or zoneid like '%'+@text+'%'  or zonecode like '%'+@text+'%' or zonename like '%'+@text+'%' or truckid like '%'+@text+'%'
 
 order by materialid desc