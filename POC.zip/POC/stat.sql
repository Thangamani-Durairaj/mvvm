-- https://docs.microsoft.com/en-us/sql/relational-databases/in-memory-oltp/sql-server-in-memory-oltp-internals-for-sql-server-2016?view=sql-server-2017

-- Ediyion - Standard
-- Max - 250 GB
-- Collation -- SQL_Latin1_General_CP1_CI_AS
-- Users - 4
-- Query Store - 100 MB

-- select count(*) from [dbo].[jobs] - 100000 - 00:00:02
-- select count(*) from [dbo].[jobs] - 1000000 - 00:02:00

select count(*) from [dbo].[jobs]

select * from [dbo].[jobs] where siteid=convert(int,3100053)

--delete from [dbo].[jobs] - 37263- 00:00:19
--- sequential -100000 - 18mm:10ss
---- bulk
select * from sys.dm_db_xtp_table_memory_stats  
where object_id = object_id('dbo.jobs')   

-- 1205579333

select * from sys.tables

SELECT 
    t.NAME AS TableName,
    s.Name AS SchemaName,
    p.rows AS RowCounts,
    SUM(a.total_pages) * 8 AS TotalSpaceKB, 
    CAST(ROUND(((SUM(a.total_pages) * 8) / 1024.00), 2) AS NUMERIC(36, 2)) AS TotalSpaceMB,
    SUM(a.used_pages) * 8 AS UsedSpaceKB, 
    CAST(ROUND(((SUM(a.used_pages) * 8) / 1024.00), 2) AS NUMERIC(36, 2)) AS UsedSpaceMB, 
    (SUM(a.total_pages) - SUM(a.used_pages)) * 8 AS UnusedSpaceKB,
    CAST(ROUND(((SUM(a.total_pages) - SUM(a.used_pages)) * 8) / 1024.00, 2) AS NUMERIC(36, 2)) AS UnusedSpaceMB
FROM 
    sys.tables t
INNER JOIN      
    sys.indexes i ON t.OBJECT_ID = i.object_id
INNER JOIN 
    sys.partitions p ON i.object_id = p.OBJECT_ID AND i.index_id = p.index_id
INNER JOIN 
    sys.allocation_units a ON p.partition_id = a.container_id
LEFT OUTER JOIN 
    sys.schemas s ON t.schema_id = s.schema_id
WHERE 
    t.NAME NOT LIKE 'dt%' 
    AND t.is_ms_shipped = 0
    AND i.OBJECT_ID > 255 
GROUP BY 
    t.Name, s.Name, p.Rows
ORDER BY 
    t.Name


	2287.38 - 40,00,000
	572 - 10,00,000
	57.2 - 1,00,000
	5.72 - 10,000