﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Reflection;
using Dapper;
using WOA.Models;
using System.Text;
using System.Web;

namespace WOA_SQL_LINQ_Perf_POC
{
    [ApiController]
    public class JobsController : ControllerBase
    {
        private readonly string connection = @"Server=tcp:eshopsqlserver.database.windows.net,1433;Initial Catalog=WOA;Persist Security Info=False;User ID=saadmin;Password=Globe@2020;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";

        // GET api/jobs/count
        [Route("api/[controller]/count")]
        [HttpGet]
        public async Task<IEnumerable<int>> GetCount()
        {
            try
            {
                object param = null;
                using (var dbContext = new SqlConnection(connection))
                {
                    return await dbContext.QueryAsync<int>("select count(*) from jobs", param);
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        // GET api/jobs/5
        [Route("api/[controller]/{siteid}")]
        [HttpGet("{siteid}")]
        public async Task<IEnumerable<Job>> Get(string siteid)
        {
            try
            {
                object param = null;
                using (var dbContext = new SqlConnection(connection))
                {
                    return await dbContext.QueryAsync<Job>("select [siteid],[sitename],[jobstate],[zoneid],[zonecode],[zonename],[truckid],[truckcode],[truckname],[materialid],[materialcode],[materialname],[loadercode],[loadername] from jobs where siteid=convert(int," + siteid + ")", param);
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        // GET api/jobs/search/12321312
        [Route("api/[controller]/search/{text}")]
        [HttpGet("{text}")]
        public async Task<IEnumerable<Job>> GetSearch(string text)
        {
            try
            {
                object param = null;
                using (var dbContext = new SqlConnection(connection))
                {
                    return await dbContext.QueryAsync<Job>("select [siteid],[sitename],[jobstate],[zoneid],[zonecode],[zonename],[truckid],[truckcode],[truckname],[materialid],[materialcode],[materialname],[loadercode],[loadername] from jobs where siteid like '%" + text + "%' or sitename like '%" + text + "%' or zoneid like '%" + text + "%' or zonecode like '%" + text + "%'  or zonename like '%" + text + "%'  or truckid like '%" + text + "%'  or truckname like '%" + text + "%'  or materialid like '%" + text + "%'  or materialcode like '%" + text + "%'  or materialname like '%" + text + "%' or loadercode like '%" + text + "%' or loadername like '%" + text + "%'", param);
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        // GET api/jobs/reports/12321312
        [Route("api/[controller]/reports/{text}")]
        [HttpGet("{text}")]
        public ActionResult GetReports(string text)
        {
            Task<IEnumerable<Job>> obj = JobRepo(text);

            StringBuilder str = new StringBuilder();

            str.Append("<table border=`" + "1px" + "`b>");

            str.Append("<tr>");

            str.Append("<td><b><font face=Arial Narrow size=3>Site Id</font></b></td>");

            str.Append("<td><b><font face=Arial Narrow size=3>Site Name</font></b></td>");

            str.Append("<td><b><font face=Arial Narrow size=3>Job State</font></b></td>");

            str.Append("<td><b><font face=Arial Narrow size=3>Zone Id</font></b></td>");

            str.Append("<td><b><font face=Arial Narrow size=3>Zone Code</font></b></td>");

            str.Append("<td><b><font face=Arial Narrow size=3>Zone Name</font></b></td>");

            str.Append("<td><b><font face=Arial Narrow size=3>Truck Id</font></b></td>");

            str.Append("<td><b><font face=Arial Narrow size=3>Truck Code</font></b></td>");

            str.Append("<td><b><font face=Arial Narrow size=3>Truck Name</font></b></td>");

            str.Append("<td><b><font face=Arial Narrow size=3>Material Id</font></b></td>");

            str.Append("<td><b><font face=Arial Narrow size=3>Material Code</font></b></td>");

            str.Append("<td><b><font face=Arial Narrow size=3>Material Name</font></b></td>");

            str.Append("<td><b><font face=Arial Narrow size=3>Loader Code</font></b></td>");

            str.Append("<td><b><font face=Arial Narrow size=3>Loader Name</font></b></td>");

            str.Append("</tr>");

            foreach (Job val in obj.Result)
            {
                str.Append("<tr>");

                str.Append("<td><font face=Arial Narrow size=" + "14px" + ">" + val.SiteId.ToString() + "</font></td>");

                str.Append("<td><font face=Arial Narrow size=" + "14px" + ">" + val.SiteName.ToString() + "</font></td>");

                str.Append("<td><font face=Arial Narrow size=" + "14px" + ">" + val.jobstate.ToString() + "</font></td>");

                str.Append("<td><font face=Arial Narrow size=" + "14px" + ">" + val.zoneid.ToString() + "</font></td>");

                str.Append("<td><font face=Arial Narrow size=" + "14px" + ">" + val.zonecode.ToString() + "</font></td>");

                str.Append("<td><font face=Arial Narrow size=" + "14px" + ">" + val.zonename.ToString() + "</font></td>");

                str.Append("<td><font face=Arial Narrow size=" + "14px" + ">" + val.truckid.ToString() + "</font></td>");

                str.Append("<td><font face=Arial Narrow size=" + "14px" + ">" + val.truckcode.ToString() + "</font></td>");

                str.Append("<td><font face=Arial Narrow size=" + "14px" + ">" + val.truckname.ToString() + "</font></td>");

                str.Append("<td><font face=Arial Narrow size=" + "14px" + ">" + val.materialid.ToString() + "</font></td>");

                str.Append("<td><font face=Arial Narrow size=" + "14px" + ">" + val.materialcode.ToString() + "</font></td>");

                str.Append("<td><font face=Arial Narrow size=" + "14px" + ">" + val.materialname.ToString() + "</font></td>");

                str.Append("<td><font face=Arial Narrow size=" + "14px" + ">" + val.loadercode.ToString() + "</font></td>");

                str.Append("<td><font face=Arial Narrow size=" + "14px" + ">" + val.loadername.ToString() + "</font></td>");

                str.Append("</tr>");
            }

            str.Append("</table>");

            HttpContext.Response.Headers.Add("content-disposition", "attachment; filename=Information" + DateTime.Now.Year.ToString() + ".xls");

            this.Response.ContentType = "application/vnd.ms-excel";

            byte[] temp = System.Text.Encoding.UTF8.GetBytes(str.ToString());

            return File(temp, "application/vnd.ms-excel");
        }

        [NonAction]
        public async Task<IEnumerable<Job>> JobRepo(string text)
        {
            try
            {
                object param = null;
                using (var dbContext = new SqlConnection(connection))
                {
                    return await dbContext.QueryAsync<Job>("select [siteid],[sitename],[jobstate],[zoneid],[zonecode],[zonename],[truckid],[truckcode],[truckname],[materialid],[materialcode],[materialname],[loadercode],[loadername] from jobs where siteid like '%" + text + "%' or sitename like '%" + text + "%' or zoneid like '%" + text + "%' or zonecode like '%" + text + "%'  or zonename like '%" + text + "%'  or truckid like '%" + text + "%'  or truckname like '%" + text + "%'  or materialid like '%" + text + "%'  or materialcode like '%" + text + "%'  or materialname like '%" + text + "%' or loadercode like '%" + text + "%' or loadername like '%" + text + "%'", param);
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}

       