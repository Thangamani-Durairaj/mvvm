﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WOA.Models
{
    public class Job 
    {
    
    public int SiteId { get; set; }
    public string SiteName { get; set; }
        public string jobstate { get; set; }
        public int zoneid { get; set; }
        public string zonecode { get; set; }
        public string zonename { get; set; }
        public int truckid { get; set; }
        public string truckcode { get; set; }
        public string truckname { get; set; }
        public int materialid { get; set; }
        public string materialcode { get; set; }
        public string materialname { get; set; }
        public string loadercode { get; set; }
        public string loadername { get; set; }
        //public DateTime? ReadyDateTime { get; set; }

      
    }
}
